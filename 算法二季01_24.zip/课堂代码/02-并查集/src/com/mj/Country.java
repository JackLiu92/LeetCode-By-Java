package com.mj;

public class Country {

}
